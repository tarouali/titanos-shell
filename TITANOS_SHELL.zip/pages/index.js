export default function Home() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>TITANOS SHELL™</h1>
      <p>Autonome AI-commandostructuur geactiveerd voor VEKTOR.</p>
      <p>Gebruik deze interface om opdrachten aan TITANOS te geven.</p>
    </main>
  );
}
